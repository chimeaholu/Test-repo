"""Agrodomain API package."""
